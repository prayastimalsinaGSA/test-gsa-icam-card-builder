##Expired CHUID Signer##

This card is produced using an expired CHUID signing cert to sign the content on the card.  All signed object properties files specify the .p12 file of the expired content signer.