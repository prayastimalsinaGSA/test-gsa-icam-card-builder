## Certs Expire After the CHUID ##

This card is produced by setting the CHUID expiration to December 2, 2024 in the c11-chuid.properties file, whereas the end-entity certificates expire on 12/1/2032. 